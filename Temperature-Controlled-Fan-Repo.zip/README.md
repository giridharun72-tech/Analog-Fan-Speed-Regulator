# Autonomous Temperature-Controlled Fan Speed Regulator

An autonomous, zero-latency temperature-controlled fan speed regulator utilizing a 100% discrete analog closed-loop (LM35, LM358, NE555) with a passive Arduino-based I2C OLED telemetry layer.

## Problem Statement
Conventional cooling systems in industrial equipment and computing enclosures rely on constant full-speed operation or abrupt relay switching. This causes excessive power consumption, high acoustic noise, accelerated mechanical bearing wear, and thermal shock. Furthermore, relying entirely on digital microcontrollers for core thermal regulation introduces software-dependent single points of failure (boot-time latency, crashes, EMI interference).

## Proposed Solution
This project implements a hybrid architecture:
1. **Analog Core (Active Cooling):** A discrete analog loop (LM35 + LM358 + NE555) generates a proportional PWM signal that directly drives an IRFZ44N MOSFET to regulate fan speed with zero software latency.
2. **Digital Telemetry (Passive Monitoring):** An Arduino Uno passively reads the analog sensor voltage via a voltage divider to display real-time status on an OLED without interfering with the hardware control loop.

## Repository Structure
- `code/`: Contains the Arduino firmware (`.ino`) for the passive OLED telemetry monitor.
- `hardware/`: Contains the system block diagram and circuit schematics.
- `docs/`: Contains the comprehensive IEEE-formatted project report and final presentation slide deck.

## Hardware Used
- **Sensors & Logic:** LM35 (Temperature), LM358 (Op-Amp), NE555 (Timer IC)
- **Power Switching:** IRFZ44N (MOSFET), 1N4007 (Flyback Diode)
- **Actuation:** 12V DC Brushless Cooling Fan
- **Telemetry:** Arduino Uno R3, 0.96-inch I2C OLED Display
- **Power:** 12V DC Supply, LM2596 Buck Converter (12V to 5V)
